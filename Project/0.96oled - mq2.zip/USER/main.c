#include "function.h"
#include "string.h"
#include "stdio.h"

uint16_t air,adcx;
char str[15];


float quality,temp;

int main(void)
{	
	delay_init();
	OLED_Init();
	MQ2_Init();
	
	while(1)
	{
		adcx=MQ2_adc_Average(10);
		temp=(float)adcx*(3.3/4096);
		quality=MQ2_Getvalue();
		sprintf(str,"air:%.2f",quality);
		OLED_ShowString(1,1,str);
	}
}
