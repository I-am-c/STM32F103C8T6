#include "function.h"
#include "string.h"
#include "stdio.h"


char buff[32];
double temp,humi;	

int main(void)
{	
	delay_init();
	OLED_Init();
	AHT10_Init();
//	if(AHT10_Init()){	    //��ʼ��AHT10               
//		while(1){
////			OLED_ShowString(2,1,"hh");
//			delay_ms(500);                             //��ʱ
//		}
//	}else OLED_ShowString(2,1,"hhhhhh");
		

	while(1)
	{
		AHT10_Data(&temp,&humi);                       //�Ƚ�У��ֵ���ɹ�������
		
		sprintf(buff,"hum:%.2f",humi);
		OLED_ShowString(1,1,buff);
		sprintf(buff,"tem:%.2f",temp);
		OLED_ShowString(2,1,buff);
	}
}


 


