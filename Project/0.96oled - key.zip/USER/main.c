#include "function.h"

int keynum;

void Key_task(void)
{
	keynum=KEY_Scan();
	if(keynum==1) //�л���ʾ����
	{
		OLED_ShowString(1,1,"hh");
	}
	else if(keynum==2)
	{
	  OLED_ShowString(2,1,"hh");
	}
}


int main(void)
{	
	delay_init();
	OLED_Init();
	KEY_Init();
	
	while(1)
	{
		Key_task();
	}
}

