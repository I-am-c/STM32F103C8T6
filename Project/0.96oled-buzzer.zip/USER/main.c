#include "function.h"

int main(void)
{	
	delay_init();
	OLED_Init();
	TIM3_PWM_Init(14399,10);
	
	while(1)
	{
		OLED_ShowString(1,1,"hhh");
		musicPlay();
		delay_ms(1500);
		delay_ms(1500);
	}
}

