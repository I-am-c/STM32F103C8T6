#include "function.h"
#include "string.h"
#include "stdio.h"

uint16_t air;
char str[15];


float quality;

int main(void)
{	
	//delay_init();
	OLED_Init();
	MQ135_Init();
	
	while(1)
	{
//		adcx=MQ135_adc_Average(10);
//		temp=(float)adcx*(3.3/4096);
		//quality=MQ135_Getvalue();
		sprintf(str,"air:%d",MQ135_value);
		OLED_ShowString(1,1,str);
	}
}

