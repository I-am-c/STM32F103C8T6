#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "stm32f10x.h"
#include "OLED.h"
#include "HC_SR501.h"

#endif
