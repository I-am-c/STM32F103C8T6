#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "stm32f10x.h"
#include "OLED.h"
#include "delay.h"
#include "DS1302.h"
#include "string.h"
#include "stdio.h"

#endif
