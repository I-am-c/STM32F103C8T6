#include "function.h"

char str[50];
extern struct TIMEData TimeData;

int main(void)
{	
	delay_init();
	OLED_Init();

	DS1302_Init();				//引脚口初始化		
	DS1302_WriteTime();			//第一次向DS1302芯片写入时间
	
	while(1)
	{
		DS1302_GetTime();
		sprintf(str,"%d%d%d-%d-%d-%d",TimeData.year,TimeData.month,TimeData.day,TimeData.hour,TimeData.minute,TimeData.second);
		OLED_ShowString(1,1,str);
		delay_ms(1000);
	}
}

