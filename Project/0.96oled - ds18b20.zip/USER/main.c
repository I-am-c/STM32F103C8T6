#include "function.h"
#include "delay.h"
#include "string.h"
#include "stdio.h"

float T;
char str[15];

int main(void)
{	
	delay_init();
	OLED_Init();
	DS18B20_Init();
	
	while(1)
	{
	  T=DS18B20_GetTemperture();
		sprintf(str,"T:%.1f       ",T);
		OLED_ShowString(1,1,(char*)str);
	}
}

