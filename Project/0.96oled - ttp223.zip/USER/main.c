#include "function.h"
#include "delay.h"

int main(void)
{	
	OLED_Init();
	TTP223_Init();
	delay_init();
	
	while(1)
	{
		if(TTP223_IN==1)
		{
		  OLED_ShowString(2,1,"hhh");
		}
		else 
		{
		  OLED_ShowString(1,1,"ee");
		}
		
	}
}

