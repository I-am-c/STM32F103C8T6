#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "stm32f10x.h"

#include "delay.h"
#include "sys.h"
#include "OLED.h"
#include "TCS34725.h"
#include "TCS34725_IIC.h"

#endif
