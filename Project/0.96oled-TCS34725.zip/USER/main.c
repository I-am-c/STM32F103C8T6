#include "function.h"

extern COLOR_RGBC rgb;

int main(void)
{	
	
	delay_init();
	OLED_Init();
	TCS34725_Init();
	
	while(1)
	{
		OLED_ShowString(2,1,"R");//��ʾ�ַ���
	  OLED_ShowString(3,1,"G");//��ʾ�ַ���
		OLED_ShowString(4,1,"B");//��ʾ�ַ���
		TCS34725_GetRawData(&rgb);
		OLED_ShowNum(2,3,((double)rgb.r)*255/rgb.c,3);
		OLED_ShowNum(3,3,((double)rgb.g)*255/rgb.c,3);
		OLED_ShowNum(4,3,((double)rgb.b)*255/rgb.c,3);
	}
}

