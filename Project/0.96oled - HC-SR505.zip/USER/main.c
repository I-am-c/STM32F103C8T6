#include "function.h"
#include "stdio.h"
#include "string.h"

char str[20];

int main(void)
{	
	OLED_Init();
	HC_SR505_Init();
	
	while(1)
	{
		sprintf(str,"s:%d",HC_SR505);
		OLED_ShowString(1,1,str);
	}
}

