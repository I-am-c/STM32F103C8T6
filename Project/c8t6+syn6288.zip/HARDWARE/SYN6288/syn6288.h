#ifndef __SYN6288_H
#define __SYN6288_H

#include "sys.h"
#include "syn6288.h"
#include "usart.h"
#include "string.h"

void SYN_FrameInfo( u8 *HZdata);
void YS_SYN_Set(u8 *Info_data);

#endif

